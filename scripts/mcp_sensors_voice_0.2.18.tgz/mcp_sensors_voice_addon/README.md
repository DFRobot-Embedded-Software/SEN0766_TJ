# MCP Sensors + Voice

给小白：装 **Mosquitto + 本 App** 即可。传感器由 App 自动登记到 HA，**不必拷自定义集成**。

步骤见 **[docs/使用说明.md](docs/使用说明.md)**。版本 **0.2.1**。
