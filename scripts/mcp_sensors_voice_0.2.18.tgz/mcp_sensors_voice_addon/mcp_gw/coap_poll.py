"""对有 CoAP 的枢纽定时读快照；CoAP 失败则试 HTTP /api/data。全自动，不填 IP。"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx

from . import config
from .coap_client import DeviceCoapClient
from .lan_discover import resolve_mdns_hosts, scan_http_hubs
from .mqtt_ha import HaMqttBridge
from .registry import DeviceRegistry

log = logging.getLogger("mcp_gw.coap_poll")


class CoapSnapshotPoller:
    def __init__(
        self,
        registry: DeviceRegistry,
        client: DeviceCoapClient,
        mqtt: HaMqttBridge,
    ) -> None:
        self.registry = registry
        self.client = client
        self.mqtt = mqtt
        self._task: asyncio.Task[Any] | None = None
        self._ok: set[str] = set()
        self._empty_n = 0
        self._last_scan = 0.0

    async def start(self) -> None:
        self._task = asyncio.create_task(self._run(), name="coap-snapshot")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def _http_data(self, host: str) -> dict[str, Any] | None:
        url = f"http://{host}/api/data"
        try:
            async with httpx.AsyncClient(timeout=8.0) as http:
                r = await http.get(url)
                r.raise_for_status()
                data = r.json()
            if isinstance(data, dict) and any(
                k in data for k in ("temp", "temperature", "humidity", "co2", "light", "lux", "sound")
            ):
                return data
            log.warning("HTTP %s 返回无环境字段: %s", url, list(data)[:12] if isinstance(data, dict) else type(data))
        except Exception as e:
            log.warning("HTTP 快照失败 %s: %s", url, e)
        return None

    async def _ensure_device_mqtt(self, rec: Any, host: str) -> None:
        """mDNS TXT 之外：单播 POST /api/wifi action=mqtt（与固件 mqtt_discover_apply 同步）。"""
        from .device_mqtt import ensure_device_mqtt
        ok = await ensure_device_mqtt(host)
        if not ok:
            log.warning(
                "id=%s %s MQTT 告知失败：烧录含 action=mqtt 的固件，插件 advertise_ip 填 HA 局域网 IP",
                rec.id,
                host,
            )

    async def _run(self) -> None:
        interval = max(5.0, float(config.COAP_POLL_S))
        log.info("快照轮询 %.0fs：先 HTTP /api/data（固件网页数据），CoAP 仅作补充", interval)
        await asyncio.sleep(5)
        while True:
            hubs = [r for r in self.registry.list_all() if r.has_coap()]
            if not hubs:
                self._empty_n += 1
                now = asyncio.get_running_loop().time()
                if now - self._last_scan > 45:
                    self._last_scan = now
                    log.info("mDNS 尚未发现枢纽，开始自动扫描局域网 HTTP /api/data")
                    await resolve_mdns_hosts(self.registry)
                    n = await scan_http_hubs(self.registry)
                    if n:
                        log.info("自动扫描登记 %s 台", n)
                    hubs = [r for r in self.registry.list_all() if r.has_coap()]
                if not hubs and (self._empty_n == 1 or self._empty_n % 4 == 0):
                    log.info(
                        "尚未发现枢纽。已听 mDNS _mcp-sensors；组播不通时会自动扫网段。"
                    )
            else:
                self._empty_n = 0
            for rec in hubs:
                host, port = rec.coap_endpoint()
                snap = await self._http_data(host)
                src = "http"
                if snap is None:
                    try:
                        got = await asyncio.wait_for(
                            self.client.get_json(host, "/sensors/snapshot", port),
                            timeout=3.0,
                        )
                        if isinstance(got, dict):
                            snap = got
                            src = "coap"
                    except Exception as e:
                        log.debug("CoAP snapshot 失败 id=%s %s:%s %s", rec.id, host, port, e)
                if not isinstance(snap, dict):
                    rec.online = False
                    rec.last_error = "CoAP/HTTP 均无快照"
                    await self.mqtt.publish_liveness(rec.id, False)
                    log.warning("读快照失败 id=%s %s", rec.id, rec.last_error)
                    continue
                rec.touch()
                rec.last_error = ""
                rec.online = True
                await self.mqtt.publish_liveness(rec.id, True)
                await self.mqtt.publish_snapshot(rec.id, snap)
                await self._ensure_device_mqtt(rec, host)
                if rec.id not in self._ok:
                    self._ok.add(rec.id)
                    log.info(
                        "快照成功 via=%s id=%s %s keys=%s",
                        src,
                        rec.id,
                        host,
                        list(snap)[:10],
                    )
            await asyncio.sleep(interval)
