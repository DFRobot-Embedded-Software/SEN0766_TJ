"""mDNS 收不到时，自动在本网段探测 HTTP /api/data（不填 IP）。

HA 跑在 macvlan/KVM 时，WiFi 设备的组播 mDNS 经常进不来，单播 HTTP 仍然通。
"""

from __future__ import annotations

import asyncio
import logging
import socket
from pathlib import Path
from typing import Any

import httpx

from . import config
from .registry import DeviceRegistry

log = logging.getLogger("mcp_gw.lan")


def _local_prefixes() -> list[str]:
    prefixes: list[str] = []
    adv = (config.ADVERTISE_IP or "").strip()
    if adv.count(".") == 3:
        prefixes.append(".".join(adv.split(".")[:3]))
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip.count(".") == 3 and not ip.startswith("127."):
            p = ".".join(ip.split(".")[:3])
            if p not in prefixes:
                prefixes.append(p)
    except OSError:
        pass
    return prefixes or ["192.168.1"]


def _arp_ips() -> dict[str, str]:
    """ip -> mac"""
    out: dict[str, str] = {}
    path = Path("/proc/net/arp")
    if not path.is_file():
        return out
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines()[1:]:
        parts = line.split()
        if len(parts) < 4:
            continue
        ip, mac = parts[0], parts[3]
        if mac == "00:00:00:00:00:00":
            continue
        out[ip] = mac
    return out


def _skip_ip(ip: str) -> bool:
    if ip in {config.ADVERTISE_IP.strip(), "127.0.0.1", "0.0.0.0"}:
        return True
    if ip.startswith(("172.17.", "172.18.", "172.19.", "172.30.", "192.168.122.", "10.8.")):
        return True
    return False


def _id_from_mac(mac: str, ip: str) -> str:
    hexmac = mac.replace(":", "").replace("-", "").lower()
    if len(hexmac) >= 6:
        return hexmac[-6:]
    return ip.split(".")[-1]


async def _probe(ip: str, mac: str) -> tuple[str, str, dict[str, Any]] | None:
    url = f"http://{ip}/api/data"
    try:
        async with httpx.AsyncClient(timeout=0.7) as client:
            r = await client.get(url)
            r.raise_for_status()
            data = r.json()
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    if not any(k in data for k in ("temp", "temperature", "humidity", "co2", "light", "lux", "sound")):
        return None
    did = str(data.get("id") or data.get("device_id") or "").strip().lower()
    if not did:
        did = _id_from_mac(mac, ip)
    return did, ip, data


async def scan_http_hubs(registry: DeviceRegistry) -> int:
    arp = _arp_ips()
    prefixes = _local_prefixes()
    skip = {config.ADVERTISE_IP.strip(), "127.0.0.1"}
    candidates: list[tuple[str, str]] = []
    seen: set[str] = set()
    for ip, mac in arp.items():
        if ip in skip or ip in seen or _skip_ip(ip):
            continue
        seen.add(ip)
        candidates.append((ip, mac))
    for pref in prefixes:
        for last in range(1, 255):
            ip = f"{pref}.{last}"
            if ip in skip or ip in seen or _skip_ip(ip):
                continue
            seen.add(ip)
            candidates.append((ip, ""))

    sem = asyncio.Semaphore(40)
    found = 0

    async def one(ip: str, mac: str) -> None:
        nonlocal found
        async with sem:
            hit = await _probe(ip, mac)
        if not hit:
            return
        did, hip, _data = hit
        registry.upsert(
            device_id=did,
            base_url=f"http://{hip}",
            name=did,
            fw=hip,
            coap_host=hip,
            coap_port=5683,
        )
        found += 1
        log.info("LAN 自动发现 HTTP 枢纽 id=%s ip=%s（mDNS 组播未到达时的回退）", did, hip)

    # 先 ARP 邻居（快），无结果再扫网段
    first = [one(ip, mac) for ip, mac in candidates if mac]
    if first:
        await asyncio.gather(*first)
    if found:
        return found
    log.info("LAN 扫描 %s.1-254 的 /api/data …", prefixes[0] if prefixes else "?")
    rest = [one(ip, mac) for ip, mac in candidates if not mac]
    await asyncio.gather(*rest)
    return found


async def resolve_mdns_hosts(registry: DeviceRegistry) -> None:
    for host in ("ris.local", "insensor.local"):
        try:
            infos = await asyncio.get_running_loop().getaddrinfo(host, 80, family=socket.AF_INET)
        except OSError:
            continue
        for item in infos:
            ip = item[4][0]
            registry.upsert(
                device_id=host.split(".")[0],
                base_url=f"http://{ip}",
                name=host,
                fw=ip,
                coap_host=ip,
                coap_port=5683,
            )
            log.info("主机名 %s → %s", host, ip)
